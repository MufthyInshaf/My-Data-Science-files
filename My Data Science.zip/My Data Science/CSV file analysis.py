
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt

file = pd.read_csv('/storage/emulated/0/Data science/datasciencetest.csv')
#b = np.repeat(a=file.values, repeats=3, axis=1)
#c = pd.DataFrame(b)

# வரைபடம் உருவாக்குதல்
digram = plt.hist(x = file['amount'])
plt.show()  # வரைபடத்தை காட்டு