# 1. Lists

print('List')
print( )


empty_card = [ ]
print(empty_card)

#----------------------------------------------------------------

print(type(empty_card))

#----------------------------------------------------------------

my_list = ["1D","Heterogenous", "Duplicate value", 2026,7,15,4.43,"indexing and slicing possible", "Mutable"] #we cant add 0 on starting of the number. becuse this is not octal value

print(my_list)

#----------------------------------------------------------------
 
print(len(my_list))

print(my_list[-1]) #Indexing

print(my_list[ 2 : 5])

my_list.remove(2026) #functions
print(my_list)

'''
append() - item add
extend() - list add
insert() - index-ல் item add
remove() - item remove
pop() - index-ல் item remove & return
index() - item-ன் index
count() - item-ன் எண்ணிக்கை
sort() - sort
reverse() - reverse

'''


# 2. Sets

print( )
print('sets')
print( )

emty_card = set( )
print (emty_card)

#----------------------------------------------------------------
 
print(type(emty_card))

#----------------------------------------------------------------
 
my_set = {"1D","Heterogenous", "wont allowed Duplicate value", "indexing and slicing not possible", 2025,3,18,4.48}

print(my_set )
print(type(my_set) )

#----------------------------------------------------------------
 
# print(my_set[-1]) - not allowed

#----------------------------------------------------------------
 
# print(my_set.count(my_set)) - can't use'

my_set.remove(3)
print(my_set)


'''

# Functions
add()      # item add
remove()   # item remove (error if not exists)
discard()  # item remove (no error)
union()    # set union
intersection() # set intersection
difference()  # set difference

'''

# 3. Tuple

print( )
print('Tuple')
print( )

emty_card = ( )
print(type(emty_card))

my_tuple = ("1D", "Heterogenous","Duplicate value is allowded", "indexing and slicing is also possible", "immutable")

print(my_tuple)   
    
#----------------------------------------------------------------

print(my_tuple[1:4])      
       
         
# 4. Dic

print( )
print('Dic')
print( )

''' 
It is a *Key:Value* Pair

- 2D
- Heterogenous
- Mutable
- Indexing & Slicing is not possible
- Don’t create duplicate key, but you can create duplicate values

'''

emty_card4 = {}
print(type(emty_card4))

my_dic = {"it's a key":"value pair","date":18, "month":5, "year":2026 }

print(my_dic)  

#----------------------------------------------------------------

# print(my_dic[ 2 : 5]) - slicing not allowed

print(my_dic["date"])

#----------------------------------------------------------------

#my_dic.clear( ) 
#print(my_dic)

a = list(my_dic.keys( ))
print(a)

b= list(my_dic.values( ))
print(b)

print( )
print('------------------------------------------------------------'
)
print( )

# Pands and dic data type uses....

import pandas as pd

my_result = {"Subjects" : ["Workplace Information & Communication" , "Engineering Drawing","Applied Electricity","Applied Electronic","Safety And Workshop","Workshop Technology"],

'result' : ["p","p","p","p","p","p"],

"code" :["SS1NVQ 091", "SS1NVQ 092", "SS1NVQ 093", "SS1NVQ 094", "SS1NVQ 095", "SS1NVQ 500"]
}


chrt = pd.DataFrame(data = my_result)

print(chrt)

print( )
print( )
print('------------------------------------------------------------'
)
print( )

print("பட்டியல் (List), தொகுப்பு (Set), டூப்பிள் (Tuple), மற்றும் அகராதி (Dictionary) இடையே தேர்வு செய்வது எப்படி என்பதை விளக்குகிறேன்.")
print("\n")                                     
print("### பட்டியல் (List)")
print("1. வரிசைப்படுத்தப்பட்டது: உறுப்புகள் வரிசையாக இருக்கும்.")
print("2. மாற்றக்கூடியது: உறுப்புகளை சேர்க்கலாம், நீக்கலாம் அல்லது மாற்றலாம்.")
print("3. திரும்பத் திரும்ப உறுப்புகள்: ஒரே உறுப்பு பல முறை இருக்கலாம்.")
print("4. பயன்பாடு: பொதுவான தரவு சேமிப்பிற்கு.")

print("\n### தொகுப்பு (Set)")
print("1.) வரிசைப்படுத்தப்படாதது: உறுப்புகளுக்கு வரிசை இல்லை.")
print("2. மாற்றக்கூடியது: உறுப்புகளை சேர்க்கலாம் அல்லது நீக்கலாம்.")
print("3. தனித்துவமான உறுப்புகள்: ஒரே உறுப்பு ஒரு முறை மட்டுமே இருக்கும்.")
print("4. பயன்பாடு: தனித்துவமான உறுப்புகள் தேவைப்படும் போது மற்றும் கணித செயல்பாடுகளுக்கு (ஒன்றியம், வெட்டு).")

print("\n")                                     
print("### டூப்பிள் (Tuple)")
print("1. வரிசைப்படுத்தப்பட்டது: உறுப்புகள் வரிசையாக இருக்கும்.")
print("2. மாற்ற முடியாதது: உருவாக்கிய பின் உறுப்புகளை மாற்ற முடியாது.")
print("3. திரும்பத் திரும்ப உறுப்புகள்: ஒரே உறுப்பு பல முறை இருக்கலாம்.")
print("4. பயன்பாடு: தரவு மாறாமல் இருக்க வேண்டும் என்றால்.")

print("\n### அகராதி (Dictionary)")
print("1. விசை-மதிப்பு ஜோடி: உறுப்புகள் விசை மற்றும் மதிப்பு ஜோடியாக சேமிக்கப்படுகின்றன.")
print("2. மாற்றக்கூடியது: விசை-மதிப்பு ஜோடிகளை சேர்க்கலாம், நீக்கலாம் அல்லது மாற்றலாம்.")
print("3. விசை தனித்துவமானது: விசைகள் தனித்துவமாக இருக்க வேண்டும்.")
print("4. பயன்பாடு: தரவை விசை மூலம் அணுக வேண்டும் என்றால்.")

print("\n")                                                                  
print("### தேர்வு செய்வது எப்படி?")
print("1. தரவு வரிசை தேவையா? - ஆம் எனில் பட்டியல் அல்லது டூப்பிள்.")
print("2. தரவு மாற வேண்டுமா? - ஆம் எனில் பட்டியல், தொகுப்பு அல்லது அகராதி.")
print("3. தனித்துவமான உறுப்புகள் தேவையா? - ஆம் எனில் தொகுப்பு.")
print("4. விசை-மதிப்பு ஜோடி தேவையா? - ஆம் எனில் அகராதி.")
print("5. தரவு மாறாமல் இருக்க வேண்டுமா? - ஆம் எனில் டூப்பிள்.")

print("\nஉங்களுக்கு எந்த தரவு அமைப்பு தேவை என்பதை தீர்மானிக்க இந்த கேள்விகளை கேட்டு தேர்வு செய்யலாம். 😊")
print("உங்கள் பயன்பாட்டிற்கு ஏற்ற தரவு அமைப்பை தேர்வு செய்ய உதவி வேண்டுமா?")


print( )
print('------------------------------------------------------------'
)
print( )

input( )