#Using Online Lib 

import seaborn as sns


# see avalible data
#print(sns.get_dataset_names( ))

print(sns.load_dataset(name = 'planets', catch = True))

