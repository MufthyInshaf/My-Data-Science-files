#3.1.1 Univaraiate Analysis

import pandas as pd

cars_data = pd.read_csv("mtcars.csv")

from matplotlib import pyplot as plt

plt.bar(cars_data["mpg"], height =cars_data["hp"] ) 

plt.show() 

# it bar graph looks bad. so we use another lib. that lib is seaborn. look 2.1 file.