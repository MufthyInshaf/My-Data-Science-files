import pandas as pd

cars_data = pd.read_csv("mtcars.csv")

import seaborn as sns
from matplotlib import pyplot as plt

sns.pairplot(data = cars_data) 

#plt.title("CYL vs MPG")
#plt.show( )