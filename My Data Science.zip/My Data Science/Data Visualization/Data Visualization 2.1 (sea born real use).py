#3.2.2 Bivaraiate Analysis

import pandas as pd

cars_data = pd.read_csv("mtcars.csv")

import seaborn as sns
from matplotlib import pyplot as plt

sns.barplot(data = cars_data, x = "cyl",y = "mpg") 

plt.title("CYL vs MPG")
plt.show( )