#3.3.3 Multivaraiate Analysis

import pandas as pd
import seaborn as sns
from matplotlib import pyplot as plt


cars_data = pd.read_csv("mtcars.csv")

sns.pairplot(data = cars_data) 
plt.show( )
