#step 1 - Import Necessary libraries

import pandas as pd


print( )
#step 2 - Import DataSheet

cars_data = pd.read_csv("mtcars.csv")

print(cars_data)


print( )
#step 1 - Data Understanding
# 3.1 - perform initial analysis

print(cars_data.shape)
print(cars_data.isna( ).sum( ))
print(cars_data.describe( ))

#3.2 - Perform Data Visualization for better understaing

from matplotlib import pyplot as plt
#import matplotlib.pyplot as plt

plt.hist(cars_data["mpg"]) #Speaks about the distribution of 1 condinuety data

plt.xlabel("MPG") # X axies name
plt.ylabel("Frequency") # y axies name
plt.title("MPG Distribution") # heading

plt.show() #remove data array


'''

2. Data Types of DataTypes

Discrete - countable / can't be measured / can't be segregated (ex: age,name)

continuous - it has some unit / it can be measured / can be segregated (ex: avarage, temp)


'''
