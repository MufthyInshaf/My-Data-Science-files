import pandas as pd

cars_data = pd.read_csv("mtcars.csv")

import seaborn as sns

sns.barplot(data = cars_data, x = "cyl",y = "mpg") 