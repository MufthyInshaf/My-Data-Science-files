#Definition


#defining a function
def login(usr_data):
    print(f'{usr_data["name"]} is login successfully')
    
    

def view_task(usr_data):
    print(f'{usr_data["name"]} is view task successfully')
    
    
    
def summit_task(usr_data):
    if usr_data["role"] == "team_members":
        print(f'{usr_data["name"]} summited done')
    else:
        print((f'{usr_data["name"]} managers no need summit task'))
        
        
    
def assign_task(usr_data):
    if usr_data["role"] == "team_members":
        print(f'{usr_data["name"]} assigned task done')
    else:
        print((f'{usr_data["name"]} team_members not allowed to assign task'))



#data collection
usr_data = {"name" : "xyz","role" : "employess"}


#function to be collected
login(usr_data)
view_task(usr_data)
summit_task(usr_data)
assign_task(usr_data)