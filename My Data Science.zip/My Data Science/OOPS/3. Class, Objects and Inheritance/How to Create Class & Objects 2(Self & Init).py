'''
Note:  
Importance of Self & Init comes into the picture

'''



class secureuserpin:
    def __init__(self,name,pin): 
        self.name = name
        self.pin = pin
    
    
    def get_pin(self,attemnt):
        return attemnt == self.pin
    
    def deposit_cash(self):
        pass
    
    def cash_withdrew(self):
        pass


        
                        
#store user data
user_data = secureuserpin("inshaf",12345)
print("------------------------------------------------------------")

#hide pin from user eye
print(user_data.get_pin(12345))

print("------------------------------------------------------------")

#Bybassing pin
print(user_data.pin)