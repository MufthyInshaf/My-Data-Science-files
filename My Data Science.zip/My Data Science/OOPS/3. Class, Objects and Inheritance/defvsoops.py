#Definition


print("Real-world analogy 1:")
print()
print("I want to reuse the same function for Team Members and Managers, but they have small differences. How do I do that?")
print()
print("Both Team Members and Managers should be able to log in, but:")
print()
print("Team Members → should log in, view tasks, and submit tasks.")
print("Managers → should log in, view tasks, and assign tasks")

print( )
print( )
print( )





#defining a function
def login(usr_data):
    print(f'{usr_data["name"]} is login successfully')
    
    

def view_task(usr_data):
    print(f'{usr_data["name"]} is view task successfully')
    
    
    
def summit_task(usr_data):
    if usr_data["role"] == "team_members":
        print(f'{usr_data["name"]} summited done')
    else:
        print((f'{usr_data["name"]} managers no need summit task'))
        
        
    
def assign_task(usr_data):
    if usr_data["role"] == "manager":
        print(f'{usr_data["name"]} assigned task done')
    else:
        print((f'{usr_data["name"]} team members not allowed to assign task'))



#data collection
usr_data = {"name" : "mufthy","role" : "team_members"}


#function to be collected
login(usr_data)
view_task(usr_data)
summit_task(usr_data)
assign_task(usr_data)