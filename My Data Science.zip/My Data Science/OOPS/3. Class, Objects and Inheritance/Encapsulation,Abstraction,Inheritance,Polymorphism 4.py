class SecureUser:
    def __init__(self, name, atm_pin):
        self.name = name
        self.__atm_pin = atm_pin  # private attribute

    def get_pin(self, attempt):
        if attempt == self.atm_pin:  # use __atm_pin, not atm_pin
        
            def deposit_cash(self):
                pass
                
            def cash_witdrwal(self):
                pass
        
        else:
            for i in range(0,3):
                if:
            
                return "your password is incorrect"
        


john_data = SecureUser ("john", 7867)

print(john_data._atm_pin)       
                
                
 '''                       
                                                               
Detailed explaination=

https://chatgpt.com/share/6a191597-9288-83ec-a9de-396a898a244d


'''