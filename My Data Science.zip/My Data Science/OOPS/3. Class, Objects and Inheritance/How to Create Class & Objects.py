# How to Create Class & Objects?

# Usecase: I want to hide sensitive data so others can’t directly access or change it.


#normal unsafe wat
atm_pin = 1234
print(atm_pin)


print("------------------------------------------------------------")
print("------------------------------------------------------------")



class secureuserpin:
    
    name = None
    pin = None
    
    
def get_pin(attemnt):
    return attemnt == pin
    
def deposit_cash( ):
    pass
    
def cash_withdrew( ):
    pass
    

#data storeing
user_data = secureuserpin
print(user_data)

print("------------------------------------------------------------")

#read user name
user_data.name = "Mufthy"
print(user_data.name)

#read pin
user_data.pin = 123098
print(user_data.pin)


# user_data.get_pin(1112)
# error code


