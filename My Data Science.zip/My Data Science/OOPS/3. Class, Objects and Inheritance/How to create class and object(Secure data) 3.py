#Not allowed

class secureuserpin:
    def __init__(self,name,pin): 
        self.name = name
        self.__pin = pin #see this __pin(restictwd)
    
    
    def get_pin(self,attemnt):
        return attemnt == self.pin
    
    def deposit_cash(self):
        pass
    
    def cash_withdrew(self):
        pass


        
                        
#store user data
user_data = secureuserpin("inshaf",1234)


#Bybassing pin
print(user_data.pin)