#My module(library)

import basic_math_fun_lib as mth

print(mth.addition(1,2))
print(mth.subtraction(1,2))
print(mth.devition(1,2))