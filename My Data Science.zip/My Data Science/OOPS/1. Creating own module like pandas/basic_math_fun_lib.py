def addition(a,b):
    return a + b
    

def subtraction(a,b):
    return a - b
    
    
def multipication(a,b):
    return a * b
    
    
def devition(a,b):
    return a / b