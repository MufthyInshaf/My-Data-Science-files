# Chapter 5 - How deal with Missing Values

#remove duplicate entries/records


#STEP NO.1 (Data cleaning)

print('- Step 0 - Reading Data File -')
print( )

import pandas as pd

employee_data = pd.read_csv("employee_data.csv")

print(employee_data)



print( )
print( )
print('- Step 1 - remove duplicate entries/records -')
print( )


employee_data.drop_duplicates(inplace = True )
#print(employee_data.duplicated( ).sum( ))
print(employee_data)

print( )

print(employee_data.shape)


print( )
print( )
print('- Step 2 - Find out the Null Entries -')
print( )

#Step 2 - Find out the Null Entries

print(employee_data.isnull( ).sum( ))

print( )

#remove Null entries
removed_null = employee_data.dropna( )
print(removed_null)

print( )

#Find the true or Correct table
print(removed_null.shape)

print( )

#Again check Null
print(removed_null.isnull( ).sum( ))



print( )
print("- Next Step (3,4) -")
print( )

print("Step 3: Record in a Document - Client gave totally 7 Observations out of which 3 entries are removed because those records do not have complete information")

print( )


print("Step 4: Get Approval - Send this to Client and get the approval to proceed for Model Building or Model Training.")


'''படி 3: ஒரு ஆவணத்தில் பதிவு செய்
- வாடிக்கையாளர் மொத்தம் 7 அவதானிப்புகளைக் கொடுத்தார், அவற்றில் 3 உள்ளீடுகள் நீக்கப்பட்டன, ஏனெனில் அந்த பதிவுகளில் முழுமையான தகவல்கள் இல்லை.

படி 4: ஒப்புதல் பெறு
- இதை வாடிக்கையாளருக்கு அனுப்பி, மாதிரி உருவாக்கம் அல்லது மாதிரி பயிற்சிக்கு செல்ல ஒப்புதல் பெறுங்கள். '''
