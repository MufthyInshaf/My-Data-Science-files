#15. Cleannig data

#read data file -> remove $ to compare with another parameter -> after that convert string to float -> after that give feedback to file name(to condinue logic  operation)

print( )
print("- Data Cleaning -" )
print( )

import pandas as pd

read_file = pd.read_csv("data.tsv.txt",sep="\t") 

read_file['item_price'] = read_file['item_price'].str.replace("$", "").astype(float) #sting to float


print(read_file)

print( )
# re check data types

print(read_file.dtypes)

print( )
# find min, max data

print(read_file.describe( ))

print( )
print( )
print( )
print( )

#TASK 1- get price from top 5 selling item

top_selling_items_revenue = read_file.groupby(by="item_name")["item_price"].sum( ).sort_values(ascending=False ).head(5)

print(top_selling_items_revenue)

#TASK 2 - get price from top 5 selling item

print( )
print( )

#TASK 3 - ask custemer site quiz from this data sheet

print("1. how many quandity sold from choise description and give with price.")
print("2. give what order id give big revenue to me")