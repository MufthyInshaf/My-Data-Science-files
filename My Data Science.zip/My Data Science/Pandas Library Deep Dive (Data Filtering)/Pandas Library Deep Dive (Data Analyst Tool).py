''' 
Pandas Library Deep Dive (Data Analyst Tool)

- DataFrames, Series, Indexing, Selection
- Data Input/Output
- Data Cleaning Techniques
- Handling Missing Data
- Data Visualization with Matplotlib, Seaborn, Plotly

'''


# Chapeter 1 - getting & knowing ur data

import pandas as pd
a = pd.read_csv(filepath_or_buffer ="data.tsv.txt", sep="\t")
print(a)

print( )
print( )
print( )
# way 2 - without using seperator(sep)
#Ex - No.1

import pandas as pd
order_info = pd.read_table(filepath_or_buffer ="data.tsv.txt")
print(order_info)


print( )
print( )
print( )
#Ex - No.2

Lvpp_ot = pd.read_table('/storage/emulated/0/Data science/datasciencetest.csv', sep = ",")
print (Lvpp_ot)


print( )
print( )
print( )


'''

1.1 Perform Initial Analysis...

Function - ( )
Attribute - no need brekcat.

Terminology Alert

- Rows - Observations/Record
-  Column - Features/Parameters

'''

# how many rows & column

cnt_data = order_info.shape
print(cnt_data) 



print( )
print( )
print( )


#1. Null finding

null_count = order_info.isnull( )
print(null_count)


print( )
print( )
print( )

#2. total Null

null_totel = order_info.isnull( ).sum( ) #chain of function,chain of commands

print(null_totel)


print( )
print( )
print( )


#3. Getting null information - num bassed

null_info = order_info.describe( )
# only show number bassed null(int)

print(null_info ) 
 
 
print( )
print( )
print( ) 
 
 
#4. Getting null information - all

null_all = order_info.describe(include = 'all')
print(null_all)


print( )
print( )
print( ) 

#5. understand pandas data type.
# int, str = object

pands_data_type = order_info.dtypes
print(pands_data_type)


input( )
