# Chapeter - 3 pandas Data stucture

# 1 . 1D - series
# 2 . 2D - DataFrame

print('- pandas Data stucture -')
print( )

print("1 . 1D - series")
print("2 . 2D - DataFrame")

print( )
print('- 1D - series -' )
print( )

#1D

import pandas as pd
print(pd.Series(data=[1,2,3,"data science", 0.456]))

print( )
print( '- 2D - series -' )
print( )

#2D

import pandas as pd
print(pd.DataFrame(data=[1,2,3,"data science", 0.456]))


print( )
print('- TASK1 - series -' )
print( )

#TASK1 - series

print(pd.Series(data = ["alchmi",'bariyan','cora','dylan','eron','faizel']))

print( )
print('- TASK2 - DataFrame -')
print( )


#TASK2 - Dataframe

print(pd.DataFrame(data = {"Maths": ["A",'B','C','D','E'], "Score":[34,23,79,21,0], "Avg": [12,16,1,14,27],"result":['fail','fail','pass','fail','rejected']}))

input( )


