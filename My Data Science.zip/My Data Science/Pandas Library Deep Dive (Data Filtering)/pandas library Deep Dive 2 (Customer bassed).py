#1.2 Findout the items sold in the restaurent


#again read the file

import pandas as pd

order_items = pd.read_csv(filepath_or_buffer = "data.tsv.txt", sep="\t")

print(order_items)

print( )
print( )
print( )

#6 find unique item. ex is 'order_id'' mean sold id. 'choise_description' mean new item quary from chef

uni_order_items = order_items.nunique( )
print(uni_order_items)

print( )
print( )
print( )

#7 after conplte filter or slice 'item_name' to see confornly sold checking items

more_sold = order_items[ "item_name"]
print(more_sold)

print( )
print( )
print( )

#8 after looking all 'item_name'' using 1 view.(on list)

print(order_items[ "item_name"].unique( ))

print( )
print( )
print( )

#1.3 Give me the list of top 5 selling items

#9 grouping ' item_name '

accsess_data = order_items.groupby(by= "item_name")

print(accsess_data)

print( )
print( )
print( )

#10 after gropued compare with another property

selling_count = order_items.groupby(by= "item_name")["quantity"].sum( )

print(selling_count)

print( )
print( )
print( )


#11 ordering low to high sold items count

selling_sort_count = order_items.groupby(by= "item_name")["quantity"].sum( ).sort_values( ) #chain mathod

print(selling_sort_count)

print( )
print( )
print( )

#11 ordering high to low sold items count

sold_high_low = order_items.groupby(by= "item_name")["quantity"].sum( ).sort_values( ascending=False) #chain mathod

print(sold_high_low)

print( )
print( )
print( )

#12 get high sold items

print(order_items.groupby(by= "item_name")["quantity"].sum( ).sort_values( ascending=False).head( ) )#chain mathod


print( )
print( )
print( )

#13 get high sold 10 items

print(order_items.groupby(by= "item_name")["quantity"].sum( ).sort_values( ascending=False).head(10 ) )#chain mathod

print( )
print( )
print( )

#14 get low sold 10 items

print(order_items.groupby(by= "item_name")["quantity"].sum( ).sort_values( ).head(10 ) )#chain mathod






