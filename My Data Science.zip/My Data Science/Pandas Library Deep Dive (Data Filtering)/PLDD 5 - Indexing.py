#Chapeter - 4 Filtering & selecction & sorting

#16 Indexing

import pandas as pd

football_tm_data = pd.read_csv('Euro_2012_stats_TEAM.csv')

print(football_tm_data)



print( )
print('- Read all columns -')
print( )

# Read all columns
print(football_tm_data.columns)




print( )
print('- read full table - Columns -')
print( )


#read full table - Columns
pd.set_option('display.max_columns', None)

print(football_tm_data)




print( )
print('- read full table - rows -')
print( )


#read full table - rows
pd.set_option('display.max_rows', None)

print(football_tm_data)



