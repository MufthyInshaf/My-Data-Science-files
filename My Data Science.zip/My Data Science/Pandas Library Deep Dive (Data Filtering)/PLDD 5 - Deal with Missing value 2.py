print("- Way 2 cleaning mathod -")
print( )



#STEP NO.2

'''
pd.read_excel ( )
#Can import Multiple Sheets

pd.read_csv( )
#you can import multiple sheets if it's in one Csv file. you need to have seperate Csv file
'''
import pandas as pd

read_excl_data = pd.read_excel("employee2_data.xlsx",sheet_name="employee2_data") 

'''if add sheet_name = "{file name}", you can read 2nd sheet data '''

print(read_excl_data)

print( )
print("- Finding Duplicates - " )
print( )

#check duplicate row
print(read_excl_data.duplicated( ))


print( )
print("- 1. Remove Duplicates row - " )
print( )

#remove duplicate row data
rem_dup = read_excl_data.drop_duplicates().copy( ) #rem waring 
print(rem_dup)


print( )
print("- 2. Identify NULL entrys - " )
print( )

total_null = read_excl_data.isna( ).sum( )
print(total_null)


print( )
print("- 3. Go for best Imputation - " )
print( )

print(read_excl_data['Department'].unique( ))

print( )

print(rem_dup[rem_dup['Department'] == 'Support'])

print( )

print(rem_dup[rem_dup['Department'] == 'IT'])

print( )

print(rem_dup[rem_dup['Department'] == 'IT Tech'])

print( )

print(rem_dup[rem_dup['Department'] == 'Ops'])



print( )
print("- Data Analytics Task - " )
print( )
print('-Task 1-')
print( )

'''
Data Analytics Task

1. Impute The relevant values in the Salary Column wherever it is NaN, based on Department Filtering.
2. Impute Mathiew's Age as 27

'''

print(rem_dup[(rem_dup['Department'] == 'Support') & (rem_dup["Salary"].isna())])

print( )

rem_dup.loc[rem_dup['Name' ] == 'Ajesh', 'Salary'] = 61000

print(rem_dup)

print( )

print(rem_dup[rem_dup['Department'] == 'Support'])


print( )
print('-Task 2-')
print( )

rem_dup.loc[rem_dup['Name' ] == 'Mathiew', 'Age'] = 27
print(rem_dup)

print( )

rem_dup.drop_duplicates(subset = ['Name','Age','Salary'], inplace = True)
print(rem_dup)

print( )
input( )