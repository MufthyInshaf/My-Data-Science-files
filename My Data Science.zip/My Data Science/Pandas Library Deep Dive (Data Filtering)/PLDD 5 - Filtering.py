#Chapeter - 4 Filtering & selecction & sorting

#17 Filtering

print('- Filtering -')
print( )

import pandas as pd

football_tm_data = pd.read_csv('Euro_2012_stats_TEAM.csv')


#Filtering favor items

football_bad_tm = football_tm_data[['Team','Goals','Red Cards','Yellow Cards']]

print(football_bad_tm)



print( )
print( )
print('- Top 5 Yellow Card Tm -')
print( )

#ordering this tm 
#Top 5 Yellow Card Tm

print(football_bad_tm.sort_values(by = 'Yellow Cards', ascending = False).head( ))


print( )
print( )
print('- List the teams Which has got red Cards -')
print( )

#4.2 List the teams Which has got red Cards

football_bad_tmm = football_bad_tm[football_bad_tm['Red Cards'] == 1]

print(football_bad_tmm) #must give same variable name. becuse every time save automatically


print( )
print( )
print('- List team which got more than yellow card -')
print( )



#4.3 List team which got more than yellow card

football_bad_tm = football_bad_tm [football_bad_tm['Yellow Cards'] > 8]


print(football_bad_tm)

# Task - get 5 quiz along with Script answer


'''

1. can you show red, yellow card tm?
2. can you fillter bad tm
3. can you get good tm
4  can you select avg playing tm
5. can you conpare goal with red card. becuse finding good perfomance.

'''


input( )


