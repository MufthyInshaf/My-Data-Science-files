import random

#new

print("Thing -> Guess the secret Number -> Earn")
print("Note: secret number below 100. Only 5 attempts.")
print("")

def new_game():

    secret_num = random.randint(1,100)

    for i in range(0, 6):
    
        try:
            usee_input = int(input("Secret Number: "))
        
            if usee_input < 0 or usee_input > 100:
                print("Invalid value. Try again")
        
            elif usee_input > secret_num:
                print("Hint - your number is higher")
        
            elif usee_input < secret_num:
                print("Hint - your number is lower")
        
            else:
                print(f"Amazing! You caught the secret number {usee_input} in {i} attempts")
                break
    
        except ValueError:
            print("Invalid Number. Please enter correctly")

    if secret_num == usee_input:
        print("We added coins to your balance")
    else:
        print("Oops... Try again")
        
new_game()