text = input("Enter text: ")
count = 0

for ch in text.lower():
    if ch in "aeiou":
        count += 1

print("Vowels:", count)


data = [1,2,3,4]
rev = []

for i in range(len(data)-1, -1, -1):
    rev.append(data[i])

print(rev)


student = {
    "name": "John",
    "age": 25,
    "city": "Colombo",
    "course": "Python",
    "grade": "A"
}

for key, value in student.items():
    print(key, value)
    
    
    
    
import pandas as pd

data = {
    "Name": ["A", "B"],
    "Age": [25,11]
}

df = pd.DataFrame(data)
print(df)







print( )
print("- Fill null Value - ")
print( )

#1. read file
import pandas as pd

employee_data = pd.read_csv("employee_data.csv")

print(employee_data )
print( )

#2. fill null value column
employee_data["Salary"].fillna(value = employee_data["Salary"].mean( ),inplace = True)

print(employee_data )





print( )
print("- Create CSV file - ")
print( )

#1. Create Data Base
Sales_info = pd.DataFrame(data ={ "Prodect Name":["Dirt remover","Drink Mixer","Robots","night ref"], "Cost" : [2700, 1300,7900,800], "Selling price" : [3500,2000,9000,1500]})


#2. conver Csv
Sales_info.to_csv(path_or_buf = "Sales_info.csv")

#3. read csv
print(pd.read_csv("Sales_info.csv"))