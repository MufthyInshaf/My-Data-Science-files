#1. Import necessary Libraries
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns  # heatmap-க்கு use ஆகும்

#2. Import Data
weight_height_data = pd.read_csv("weight-height.csv")

#3. Data Understanding
print("=== DATA SHAPE ===")
print(weight_height_data.shape)
print("\n=== MISSING VALUES ===")
print(weight_height_data.isna().sum())
print("\n=== DATA TYPES ===")
print(weight_height_data.dtypes)
print("\n")

#4. Data Preparation - Feature Engineering
weight_height_data_copied = weight_height_data.copy()

del weight_height_data_copied['Gender']

# Inch to cm
weight_height_data_copied['Height_cm'] = weight_height_data_copied['Height'] * 2.54

# pounds to kg
weight_height_data_copied['Weight_kg'] = weight_height_data_copied['Weight'] / 2.205

print("=== AFTER FEATURE ENGINEERING ===")
print(weight_height_data_copied.head())
print("\n")

#5. LET'S PERFORM ASSUMPTION TEST

# Assumption 1 - Normal Test
# weight_height_data_copied['Weight_kg'].hist(bins=30)
# plt.title('Normal Test - Weight')
# plt.show()

# Assumption 2 - Linearity Test
# weight_height_data_copied.plot(x = "Weight_kg", y ="Height_cm", kind = 'scatter')
# plt.title('Linearity Test')
# plt.show()

# Assumption 3 - Multicollinearity  <<--- இதுதான் வேணும்
print("=== ASSUMPTION 3: CORRELATION MATRIX ===")
corr_matrix = weight_height_data_copied.corr()
print(corr_matrix)  # <-- இதுதான் table-ஆ print பண்ணும்

# Heatmap-ஆவும் பார்கலாம் - ரொம்ப அழகா இருக்கும்
plt.figure(figsize=(8,6))
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', fmt='.2f')
plt.title('Assumption 3: Multicollinearity Heatmap')
plt.show()