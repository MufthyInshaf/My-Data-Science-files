#1. Import necessary Libraries

import pandas as pd

#2. Import Data
gender_classification = pd.read_csv("weight-height.csv")

print(gender_classification)

#3. Data Understanding

gender_classification.shape
gender_classification.isna( ).sum( )
gender_classification.dtypes #str

#4. Data preparetion

gender_classification.head( )

''' gender_classification["Gender"] = gender_classification["Gender"].replace(to_replace=['Male','Female'],value=[0,1]) '''

gender_classification["Gender"] = gender_classification["Gender"].replace(['Male','Female'],[0,1]).astype(int)


gender_classification.dtypes #obj


#Inch to cm
gender_classification['Height'] = gender_classification['Height'] * 2.54

#pounds to kg
gender_classification['Weight'] = gender_classification['Weight'] / 2.205


#5. Model Building

x = gender_classification.drop('Gender',axis=1)

#y = gender_classification[['Gender']]
y = gender_classification['Gender']

#6. Model Trainning

from sklearn.linear_model import LogisticRegression

logistic_model = LogisticRegression( )

logistic_model.fit(x,y)

LogisticRegression( )

logistic_model.coef_
logistic_model.intercept_

#7. Model Testing

logistic_model.predict(x)

logistic_model.predict_proba(x)

y_pred = logistic_model.predict(x)


#8. Model Evaluvation

from sklearn.metrics import accuracy_score

accuracy_score(y,y_pred)

#9. Model deployment

'''

from pickle import dump

dump(logistic_model,open('gender_classification_intelligence.pkl','wb')) 


'''
