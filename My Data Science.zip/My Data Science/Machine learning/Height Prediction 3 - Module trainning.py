#1. Import necessary Libraries

import pandas as pd


#2. Import Data
weight_height_data = pd.read_csv("weight-height.csv")


#3. Data Understanding

'''
print(weight_height_data.shape)
print( )
print(weight_height_data.isna( ).sum( ))
print( )
print(weight_height_data.dtypes)
print( )

'''

#print('weight_height_data')

#4. Data Preparation

'''
Let’s do Feature Engineering
It is nothing but a concept of whatever you do with Features, we call it as Feature Engineering.

- Feature Deletion
- Feature Addition
- Feature Selection
- Feature Decomposotion
- Feature Transformation

We are interested to convert units of Height from Inches to cm and Weight from pounds to Kg.

'''
weight_height_data_copied = weight_height_data.copy( )

del weight_height_data_copied['Gender']

#print(weight_height_data_copied)

#Inch to cm
weight_height_data_copied['Height_cm'] = weight_height_data_copied['Height'] * 2.54

#pounds to kg
weight_height_data_copied['Weight_kg'] = weight_height_data_copied['Weight'] / 2.205

#print(weight_height_data_copied)


#5 Module Building

x = weight_height_data_copied[['Weight_kg']] 

y = weight_height_data_copied[['Height_cm']] 

#print(x)

#6 Model Training


from sklearn.linear_model import LinearRegression 

linear_model = LinearRegression( )

print(linear_model.fit(x,y))

print( )

print(linear_model.coef_)

print( )

print(linear_model.intercept_)

print( )

#7. Model Tesing

# a. Manual testing


# y = mx + c
# If Weight is 95kg, what will be the Height?

#Height = coef × Weight + intercept

y1 = 0.62062922 * 95 + 123.13387264
print("Height =", y1)


# If Weight is 75kg, what will be the Height?

y2 = 0.62062922 * 75 + 123.13387264
print("Height =", y2)

# If Weight is 110kg, what will be the Height?

y3 = 0.62062922 * 110 + 123.13387264
print("Height =", y3)

print( )

# b. Automatic Prediction

'''

x_test = pd.DataFrame(data = [95,75,110])
print(x_test)

re = linear_model.predict(x_test)
print(re) 

'''


#full file data predicted results
y_predict = linear_model.predict(x)
print(y_predict) 

