#1. Import necessary Libraries

import pandas as pd


#2. Import Data
weight_height_data = pd.read_csv("weight-height.csv")


#3. Data Understanding

print(weight_height_data.shape)
print( )
print(weight_height_data.isna( ).sum( ))
print( )
print(weight_height_data.dtypes)
print( )

#print('weight_height_data')

#4. Data Preparation

'''
Let’s do Feature Engineering
It is nothing but a concept of whatever you do with Features, we call it as Feature Engineering.

- Feature Deletion
- Feature Addition
- Feature Selection
- Feature Decomposotion
- Feature Transformation

We are interested to convert units of Height from Inches to cm and Weight from pounds to Kg.

'''
weight_height_data_copied = weight_height_data.copy( )

del weight_height_data_copied['Gender']

#print(weight_height_data_copied)

#Inch to cm
weight_height_data_copied['Height_cm'] = weight_height_data_copied['Height'] * 2.54

#pounds to kg
weight_height_data_copied['Weight_kg'] = weight_height_data_copied['Weight'] / 2.205

print(weight_height_data_copied)