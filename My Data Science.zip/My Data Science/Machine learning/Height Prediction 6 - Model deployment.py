#1. Import necessary Libraries

import pandas as pd

#2. Import Data
weight_height_data = pd.read_csv("weight-height.csv")


#3. Data Understanding

'''
print(weight_height_data.shape)
print( )
print(weight_height_data.isna( ).sum( ))
print( )
print(weight_height_data.dtypes)
print( )

'''

#print('weight_height_data')

#4. Data Preparation

'''
Let’s do Feature Engineering
It is nothing but a concept of whatever you do with Features, we call it as Feature Engineering.

- Feature Deletion
- Feature Addition
- Feature Selection
- Feature Decomposotion
- Feature Transformation

We are interested to convert units of Height from Inches to cm and Weight from pounds to Kg.

'''
weight_height_data_copied = weight_height_data.copy( )

del weight_height_data_copied['Gender']

#print(weight_height_data_copied)

#Inch to cm
weight_height_data_copied['Height_cm'] = weight_height_data_copied['Height'] * 2.54

#pounds to kg
weight_height_data_copied['Weight_kg'] = weight_height_data_copied['Weight'] / 2.205

#print(weight_height_data_copied)


#5 Module Building

x = weight_height_data_copied[['Weight_kg']] 

y = weight_height_data_copied[['Height_cm']] 

#print(x)

#6 Model Training


from sklearn.linear_model import LinearRegression 

linear_model = LinearRegression( )

linear_model.fit(x,y)

#print( )

linear_model.coef_

#print( )

linear_model.intercept_

#print( )

#7. Model Tesing

# a. Manual testing


# y = mx + c
# If Weight is 95kg, what will be the Height?

#Height = coef × Weight + intercept

y1 = 0.62062922 * 95 + 123.13387264
#print("Height =", y1)


# If Weight is 75kg, what will be the Height?

y2 = 0.62062922 * 75 + 123.13387264
#print("Height =", y2)

# If Weight is 110kg, what will be the Height?

y3 = 0.62062922 * 110 + 123.13387264
#print("Height =", y3)

#print( )

# b. Automatic Prediction


x_test = pd.DataFrame(data = [95,75,110])
#print(x_test)

re = linear_model.predict(x_test)
#print(re) 




#full file data predicted results
y_predict = linear_model.predict(x)
#print(y_predict)



#8. Model Evaluvation

#print(y)
#print(y_predict)

error = y - y_predict
#print(error)

error.mean( )


# Let's check Assumption 5: Homocadacity Test

#It is a plot between input and output error

'''

plt.scatter(x = weight_height_data_copied['Weight_kg'], y = error)

plt.xlabel('Input')
plt.ylabel('Error')

'''

'''
plt.scatter(x = y,y = y_predict)

plt.xlabel('Actual O/P')
plt.ylabel('Predicted O/P')

plt.show( )

'''


# 9. Model Deployment

'''

#1. Create file

from pickle import dump

dump(linear_model,open('height_intelligence.pkl','wb')) 
#write bytes

'''

#2. Read file

from pickle import load

loaded_intelligence = load(open('height_intelligence.pkl','rb'))

loaded_intelligence.predict(x_test)



print( )

# b. Automatic Prediction
x_test = pd.DataFrame(data = [[95],[75],[110]], columns=['Weight_kg']) # column name add pannu
print(x_test)

print( )

re = linear_model.predict(x_test)
print(re) 

# Last line kum
loaded_intelligence.predict(x_test)

#THE END